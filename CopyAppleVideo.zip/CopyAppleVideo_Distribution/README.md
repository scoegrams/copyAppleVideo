# copyAppleVideo
App to copy videos and photos on Apple MacOS for filmmakers and photographers
